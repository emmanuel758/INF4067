public class ProduitA1 extends ProduitA {

    @Override
    public void methodA() {
        System.out.println("Je suis un produit de type A1");
        System.out.println("ProduitA1.methodA()");
    }

}