public interface Carree {
    public void setCote(float c);

    public float perimetre();

    public float aire();

    public void affiche();
}
