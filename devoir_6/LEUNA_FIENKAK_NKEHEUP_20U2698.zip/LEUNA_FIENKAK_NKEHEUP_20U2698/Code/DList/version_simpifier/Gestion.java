public class Gestion{
    public static void main(String[] args) {
        
    }
}