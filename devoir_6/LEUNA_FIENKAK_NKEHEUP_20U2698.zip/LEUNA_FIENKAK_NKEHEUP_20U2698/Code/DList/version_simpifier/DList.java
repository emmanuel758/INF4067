public class DList {
    public void insert(int pos, Object o) {
    }

    public void remove(int pos) {
    };

    public void insertHead(Object o) {
    };

    public void insertTail(Object o) {
    };

    public Object removeHead() {
        return null;
    };

    public Object removeTail() {
        return null;
    }

    public Object getHead() {
        return null;
    }

    public Object getTail() {
        return null;
    }
}
