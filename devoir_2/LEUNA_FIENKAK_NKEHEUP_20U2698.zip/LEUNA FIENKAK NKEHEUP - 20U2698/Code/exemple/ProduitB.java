package devoir_2.Code.exemple;

public abstract class ProduitB {

    public abstract void methodeB();
}
