package devoir_2.Code.exemple;

public class ProduitA2 extends ProduitA {

    public void methodeA() {
        System.out.println("ProduitA2.methodeA()");
    }
}
