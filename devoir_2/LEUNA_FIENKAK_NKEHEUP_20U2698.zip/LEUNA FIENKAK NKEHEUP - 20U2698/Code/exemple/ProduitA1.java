package devoir_2.Code.exemple;

public class ProduitA1 extends ProduitA {

    public void methodeA() {
        System.out.println("ProduitA1. methode A()");
    }
}

