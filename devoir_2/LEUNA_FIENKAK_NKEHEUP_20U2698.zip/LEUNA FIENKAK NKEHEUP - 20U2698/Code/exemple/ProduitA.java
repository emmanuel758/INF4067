package devoir_2.Code.exemple;

public abstract class ProduitA {

    public abstract void methodeA();
}
