package devoir_2.Code.exemple;

public interface IProduitFactory {
    public ProduitA geProduitA();
    public ProduitB geProduitB();
}


