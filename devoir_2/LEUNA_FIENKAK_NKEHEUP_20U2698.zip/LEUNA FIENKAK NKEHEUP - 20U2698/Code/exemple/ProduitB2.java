package devoir_2.Code.exemple;

public class ProduitB2 extends ProduitB {

    public void methodeB() {
        System.out.println("ProduitB2. methode B()");
    }
}

