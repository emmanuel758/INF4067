package devoir_2.Code.exempleModifier;

public abstract class ProduitA {

    public abstract void methodeA();
}
