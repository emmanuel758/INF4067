package devoir_2.Code.exempleModifier;

public interface IProduitFactory {
    public ProduitA geProduitA();

    public ProduitB geProduitB();
}
