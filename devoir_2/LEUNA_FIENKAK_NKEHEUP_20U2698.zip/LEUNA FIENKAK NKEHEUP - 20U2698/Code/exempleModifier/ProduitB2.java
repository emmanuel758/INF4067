package devoir_2.Code.exempleModifier;

public class ProduitB2 extends ProduitB {

    public void methodeB() {
        System.out.println("ProduitB2. methode B()");
    }
}

