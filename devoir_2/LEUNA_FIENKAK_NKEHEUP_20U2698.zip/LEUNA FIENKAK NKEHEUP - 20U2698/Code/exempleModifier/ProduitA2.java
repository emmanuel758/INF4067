package devoir_2.Code.exempleModifier;

public class ProduitA2 extends ProduitA {

    public void methodeA() {
        System.out.println("ProduitA2.methodeA()");
    }
}
