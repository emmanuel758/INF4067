package devoir_2.Code.exempleModifier;

public class ProduitB1 extends ProduitB {

    public void methodeB() {
        System.out.println("ProduitB1. methode B()");
    }
}

