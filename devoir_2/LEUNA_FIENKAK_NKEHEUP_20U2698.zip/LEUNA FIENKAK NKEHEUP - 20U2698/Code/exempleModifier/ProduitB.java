package devoir_2.Code.exempleModifier;

public abstract class ProduitB {

    public abstract void methodeB();
}
