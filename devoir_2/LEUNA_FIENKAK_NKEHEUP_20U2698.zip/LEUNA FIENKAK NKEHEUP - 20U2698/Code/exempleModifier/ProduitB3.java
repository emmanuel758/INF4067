package devoir_2.Code.exempleModifier;

public class ProduitB3 extends ProduitB {

    public void methodeB() {
        System.out.println("ProduitB3. methode B()");
    }
}

