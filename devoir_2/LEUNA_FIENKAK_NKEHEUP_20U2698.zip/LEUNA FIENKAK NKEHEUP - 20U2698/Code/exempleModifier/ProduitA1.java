package devoir_2.Code.exempleModifier;

public class ProduitA1 extends ProduitA {

    public void methodeA() {
        System.out.println("ProduitA1. methode A()");
    }
}

