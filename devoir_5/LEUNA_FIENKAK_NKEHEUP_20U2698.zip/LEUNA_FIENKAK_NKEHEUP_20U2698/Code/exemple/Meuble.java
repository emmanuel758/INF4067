public abstract class Meuble {
    protected String couleur;

    public abstract Meuble Copy();

    public abstract void affiche();
}