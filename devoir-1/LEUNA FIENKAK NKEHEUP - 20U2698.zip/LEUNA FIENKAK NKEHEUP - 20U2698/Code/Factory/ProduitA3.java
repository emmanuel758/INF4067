public class ProduitA3 extends ProduitA {

    @Override
    public void methodA() {
        System.out.println("Je suis un produit de type A3");
        System.out.println("ProduitA3.methodA()");
    }

}